# gtps by user95401

Main mod for Gemetry Trash Private Servero

## <co>Converted for Geode</c>
---

<cr>This is traditional mod that uses minhook, gd.h, cocos-haders!

BUT! In general, this mod works, and IN MOST CASES IT is COMPATIBLE.
- Made with curly-eureka</c>
